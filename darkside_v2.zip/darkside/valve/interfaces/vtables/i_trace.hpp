#pragma once

#include "../../../sdk/vfunc/vfunc.hpp"

#include <array>
#include "../../../sdk/typedefs/vec_t.hpp"
#include "../../modules/modules.hpp"
#include "../../../utils/utils.hpp"

struct ray_t
{
public:
	vec3_t m_start{};
	vec3_t m_end{};
	vec3_t m_mins{};
	vec3_t m_maxs{};
	std::byte pad_001[ 0x4 ];
	std::uint8_t type{};
};
static_assert( sizeof( ray_t ) == 0x38 );

struct surface_data_t
{
public:
	std::byte pad_001[ 0x8 ];
	float m_pen_data_modifier{};
	float m_dmg_modifier{};
	std::byte pad_002[ 0x4 ];
	int m_material{};
};

static_assert( sizeof( surface_data_t ) == 0x18 );

struct trace_hitbox_data_t
{
public:
	std::byte pad_001[ 0x38 ];
	int m_hit_group{};
	std::byte pad_002[ 0x4 ];
	int m_hitbox_id{};
};
static_assert( sizeof( trace_hitbox_data_t ) == 0x44 );

struct trace_array_element_t {
	std::byte pad_001[ 0x38 ];
};

struct trace_data_t {
	std::int32_t uk1{};
	float uk2{ 52.0f };
	void* arr_pointer{};
	std::int32_t uk3{ 128 };
	std::int32_t uk4{ static_cast<std::int32_t>( 0x80000000 ) };
	std::array<trace_array_element_t, 0x80> arr{};
	std::byte pad_001[0x8]{};
	std::int32_t num_update{};
	std::int32_t uk5{};
	void* pointer_update_value{};
	std::int32_t hit_capacity{ 8 };
	std::int32_t hit_flags{ static_cast<std::int32_t>( 0x80000000 ) };
	std::byte hit_elements[0xC0]{};
	vec3_t start{}, end{};
	float fraction{ 1.f };
	bool uk6{};
	std::byte pad_003[0x4B]{};
};

static_assert(offsetof(trace_data_t, arr) == 0x18);
static_assert(offsetof(trace_data_t, num_update) == 0x1C20);
static_assert(offsetof(trace_data_t, pointer_update_value) == 0x1C28);
static_assert(offsetof(trace_data_t, start) == 0x1CF8);
static_assert(sizeof(trace_data_t) == 0x1D60);

struct update_value_t {
	float m_previous_length_mod{ };
	float m_current_length_mod{ };
	std::byte pad_001[ 0x8 ];
	short m_handle_index{ };
	std::byte pad_002[ 0x6 ];
};

class c_cs_player_pawn;

struct game_trace_t
{
public:
	game_trace_t() = default;

	int get_hitbox_id();
	int get_hit_group();

	void* m_surface{};
	c_cs_player_pawn* m_hit_entity{};
	trace_hitbox_data_t* m_hitbox_data{};
	std::byte pad_001[0x38];
	std::uint32_t m_contents{};
	std::byte pad_002[0x24];
	vec3_t m_start{};
	vec3_t m_end{};
	vec3_t m_normal{};
	vec3_t m_pos{};
	std::byte pad_003[0x4];
	float m_fraction{};
	std::byte pad_004[0x6];
	bool m_all_solid{};
	std::byte pad_005[0x4D];
};

static_assert( sizeof( game_trace_t ) == 0x108 );

struct trace_filter_t
{
public:
	void* m_vtable{};
	std::uint64_t m_mask{};
	std::array<int64_t, 2> m_ptr{};
	std::array<int32_t, 4> m_skip_handles{};
	std::array<int16_t, 2> m_arr_collisions{};
	std::byte pad_0034[3]{};
	std::uint8_t m_trace_type{};
	std::uint8_t m_layer{};
	std::uint8_t m_flags{};
	std::byte pad_003A[6]{};
	char m_v7{};

	trace_filter_t( ) = default;
	trace_filter_t( std::uint64_t mask, c_cs_player_pawn* entity, c_cs_player_pawn* player, int layer, int type = 7 );
};
static_assert( sizeof( trace_filter_t ) == 0x48 );
static_assert(offsetof(trace_filter_t, m_trace_type) == 0x37);
static_assert(offsetof(trace_filter_t, m_layer) == 0x38);

class i_trace
{
	using fn_init_trace_info = void(__fastcall*) (game_trace_t*);
	using fn_get_trace_info = void(__fastcall*) (trace_data_t*, game_trace_t*, float, void*);
public:
	bool init_trace(trace_filter_t& filter, c_cs_player_pawn* pawn, uint64_t mask, uint8_t layer) {
		using fn_init_trace_t = void (__fastcall*)(trace_filter_t*, void*, uint64_t, int);
		static fn_init_trace_t fn = reinterpret_cast<fn_init_trace_t>(g_opcodes->scan(g_modules->m_modules.client_dll.get_name(), "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F B6 41 ? 33 FF 24"));
		if (!fn)
			return false;
		fn(&filter, pawn, mask, layer);
		return filter.m_vtable != nullptr;
	}

	bool create_trace(trace_data_t* const trace, const vec3_t& start, const vec3_t& end, const trace_filter_t& filter, int penetration_count) {
		if (!trace || !filter.m_vtable || !trace->arr_pointer || !trace->pointer_update_value)
			return false;
		using fn_create_trace_t = void(__fastcall*) (trace_data_t*, const vec3_t&, const vec3_t&, const trace_filter_t&, int, bool);
		static fn_create_trace_t fn = reinterpret_cast<fn_create_trace_t>(g_opcodes->scan(g_modules->m_modules.client_dll.get_name(), "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC 40 F2 0F 10 02 4D 8D 71 08"));
		if (!fn)
			return false;
			fn(trace, start, end, filter, penetration_count, 1);
		return true;
	}

	void init_trace_info(game_trace_t* const hit) {
		static fn_init_trace_info fn = reinterpret_cast<fn_init_trace_info>(g_opcodes->scan(g_modules->m_modules.client_dll.get_name(), "40 55 41 55 41 57 48 83 EC"));

		fn(hit);
	}

	void get_trace_info(trace_data_t* const trace, game_trace_t* const hit, const float unknown_float, void* unknown) {
		static fn_get_trace_info fn = reinterpret_cast<fn_get_trace_info>(g_opcodes->scan(g_modules->m_modules.client_dll.get_name(), "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 81 EC 80 00 00 00 48 8B E9 0F 29 74 24 ? 48 8B CA 49 8B F9"));

		fn(trace, hit, unknown_float, unknown);
	}

	bool trace_shape(ray_t* ray, vec3_t start, vec3_t end, trace_filter_t* filter, game_trace_t* game_trace)
	{
		using fn_trace_shape = bool(__fastcall*)(i_trace*, ray_t*, vec3_t*, vec3_t*, trace_filter_t*, game_trace_t*);
		static fn_trace_shape o_trace_shape = reinterpret_cast<fn_trace_shape>(g_opcodes->scan(g_modules->m_modules.client_dll.get_name(), "48 89 54 24 10 48 89 4C 24 08 55 53 56 57 41 54 41 56 41 57 48 8D AC 24 ? ? ? ? B8 10 25 00 00"));
		if ( !o_trace_shape )
			return false;

		return o_trace_shape(this, ray, &start, &end, filter, game_trace);
	}

};
