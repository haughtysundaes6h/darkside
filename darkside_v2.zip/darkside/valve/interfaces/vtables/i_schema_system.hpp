#pragma once
#include "../../sdk/vfunc/vfunc.hpp"

struct c_schema_class_field {
    const char* m_name;
    char pad0[ 0x8 ];
    std::uint32_t m_offset;
    char pad1[ 0xC ];
};

class c_schema_class_info {
public:
    const char* get_name( ) {
        return *reinterpret_cast<const char**>( (unsigned __int64)( this ) + 0x8 );
    };
    std::uint16_t get_fields_size( ) {
        return *reinterpret_cast<std::uint16_t*>( (unsigned __int64)( this ) + 0x24 );
    };
    c_schema_class_field* get_fields( ) {
        return *reinterpret_cast<c_schema_class_field**>( (unsigned __int64)( this ) + 0x30 );
    };
};

class c_schema_type_scope {
public:
    c_schema_class_info* find_declared_class( const char* className ) {
        c_schema_class_info* rv = nullptr;
        VFUNC( this, void, 2, &rv, className );

        return rv;
    };
};

class i_schema_system {
public:
    c_schema_type_scope* find_type_scope_for_module( const char* moduleName ) {
        return VFUNC( this, c_schema_type_scope*, 13, moduleName, nullptr );
    };
};
